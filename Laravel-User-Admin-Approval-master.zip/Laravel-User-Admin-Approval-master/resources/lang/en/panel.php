<?php

return [
    'site_title' => 'Approval Demo',
];
