<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\bahan laravel\Laravel-User-Admin-Approval-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>