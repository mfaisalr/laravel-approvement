<?php echo e($slot); ?>

<?php /**PATH D:\bahan laravel\Laravel-User-Admin-Approval-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>